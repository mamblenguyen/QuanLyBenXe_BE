<?php

namespace App\Repositories\Implementations;

interface BaseRepositoryInterface
{
    public function getAll($garage_id);
    public function find($id);
    public function create(array $data);
    public function update($id, array $data);
    public function delete($id);
}
