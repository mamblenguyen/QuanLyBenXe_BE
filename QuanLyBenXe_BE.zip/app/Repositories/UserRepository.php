<?php

namespace App\Repositories;

use App\Models\User;
use App\Repositories\Implementations\UserRepositoryInterface;

class UserRepository extends BaseRepository implements UserRepositoryInterface
{
    public function __construct(User $model)
    {
        parent::__construct($model);
    }

    public function getUserByEmail($email)
    {
        return $this->model->where('email', $email)->first();
    }

}
